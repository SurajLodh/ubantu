requirement softwares

---------------(manually download install n set path to the system enviroment)------------------------

jdk   https://drive.google.com/file/d/1S3x5NQrmhC7N7328gxWvy9iUonjSsccP/view?usp=sharing
jre   https://drive.google.com/file/d/1J44Axwh7Mh-le_MYhZkZNocG1cwdgmzy/view?usp=sharing
mysql  https://drive.google.com/file/d/1xuZlEt1OJVObCilmUu_NnCJ2ylxlez2B/view?usp=sharing
maven   https://drive.google.com/file/d/1VfiUfqbLXWUGjaQQE-MQSg-Wd1wQFf-v/view?usp=sharing

(add on) given 
mysql connector 8.0.18 
simple json 1.1.1    


---------------------------------------------- This readme file is only for Customer -----------------------------------------------

mvn archetype:generate -DarchetypeArtifactId=jersey-quickstart-grizzly2 -DarchetypeGroupId=org.glassfish.jersey.archetypes -DinteractiveMode=false -DgroupId=mybank -DartifactId=mybankservice -Dpackage=mybank -DarchetypeVersion=2.17

pom.xml -> change 1.7 to 1.8

mvn clean compile

mvn exec:java
(showing got it)

(add->)
<dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>8.0.18</version>       
        </dependency>
		
		<!-- https://mvnrepository.com/artifact/com.googlecode.json-simple/json-simple -->
		<dependency>
			<groupId>com.googlecode.json-simple</groupId>
			<artifactId>json-simple</artifactId>
			<version>1.1.1</version>
		</dependency>
		
		<dependency>
            <groupId>mysql</groupId>
            <artifactId>jdatabase</artifactId>
            <version>1.0</version>       
        </dependency>

mvn clean compile

mvn exec:java
(showing got it)

add json-simple-1.1.1.jar & mysql-connector-java-8.0.18.jar

mvn install:install-file -Dfile=C:\Deepak\mysql-connector-java-8.0.18.jar -DgroupId=mysql -DartifactId=mysql-connector-java -Dversion=8.0.18 -Dpackaging=jar -DgeneratePom=true

mvn install:install-file -Dfile=C:\Deepak\json-simple-1.1.1.jar -DgroupId=com.googlecode.json-simple -DartifactId=json-simple -Dversion=1.1.1 -Dpackaging=jar -DgeneratePom=true


copy n paste frome jdatabase folder dbconfig_costomer.json ,dbsql and serviceCommmon
Also, Copy dbconfig_customer.json in the folder where mybankservice is.

also copy mybankwebsite

mysqld


copy n paste tcustomer.csv 

copy n paste create_customer_database into jdatabase folder

jdatabase->mysql –u root –p < create_customer_database.sql

Cloud(home)>javac -cp "json-simple-1.1.1.jar";"mysql-connector-java-8.0.18.jar"; jdatabase\*.java


java -cp "json-simple-1.1.1.jar";"mysql-connector-java-8.0.18.jar"; jdatabase.dbsql

jar cvf jdatabase.jar ./jdatabase/*.class json-simple-1.1.1.jar mysql-connector-java-8.0.18.jar

mybankservice->mvn install:install-file -Dfile=C:\Deepak\jdatabase.jar -DgroupId=mysql -DartifactId=jdatabase -Dversion=1.0 -Dpackaging=jar -DgeneratePom=true

copy n paste maincustomer.java & svcCustomer.java file n paste into mybank n delete existing files

Open the svcCustomer.java file and edit the dbsql constructor to - 
 public svcCustomer(){
	db = new dbsql(); //create the database object  
  }

mvn clean compile






